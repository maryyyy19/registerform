-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2024 at 01:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_register`
--

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `email`, `telephone`, `address1`, `address2`, `city`, `province`, `zip`, `username`, `password`) VALUES
(5, 'asd', 'SAD@HKLP.COM', '2123', 'dsa', 'sda', 'fads', 'w', '12', 'mary', '$2y$10$5ihJYPaCwp.V/O5vVxLL0uK2sgr3SM8oJTBsiAxAVZp1GK.QrTmKm'),
(6, 'sda', 'sd@d', '231', 'sead', 'asd', 'sadsa', 'asd', '12', 'mary1', '$2y$10$eoqzeErO6u6SQiiVgJf4rOql.zDhUmtn3zjZMjtCFoh4ZJmbDg98G'),
(23, 'ASD', 'SD@DSK.COM', '921380', 'JKWEL', '218', 'WLQE', 'AEHSIJ', '2917', 'AN', '$2y$10$IHay1w9oFCRcqkxrMhOo5uOyovg./HNtK6WyDCeX397q95P9628h6'),
(28, 'sda', 'maryjoycedolor19@gmail.com', '234', 'ewr', 'erfds', 'dsf', 'df', '23', 'aa', '??X??R?e?T????a?7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
